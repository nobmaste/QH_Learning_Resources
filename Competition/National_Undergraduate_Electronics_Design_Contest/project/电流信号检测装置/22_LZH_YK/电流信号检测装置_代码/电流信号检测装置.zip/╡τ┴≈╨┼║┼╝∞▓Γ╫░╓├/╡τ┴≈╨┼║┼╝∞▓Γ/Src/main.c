/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "fsmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "arm_math.h"
#include "stdio.h"
#include "ad9833.h"
#include "lcd.h"
#include "interrupt.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define FFT_LENGTH		4096 		//FFT���ȣ�Ĭ����1024��FFT
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/*ȫ�ֱ�������main֮ǰ����*/
arm_cfft_radix4_instance_f32 scfft;//����scfft�ṹ��
float FFT_InputBuf[FFT_LENGTH*2];	//FFT��������
float FFT_OutputBuf[FFT_LENGTH];	//FFT�������
uint16_t ADC_1_Value_DMA[FFT_LENGTH] = {0};//���ADC��ֵ
float Harmonic_Amplitude[19]={0,0};
uint16_t Harmonic_Frequency[19]={0,0};

uint16_t i=0,n=0,j=0,k=0;
float Fundamental_wave=0,Fundamental_wave1=0;
uint16_t Fundamental_wave_f=0,Fundamental_wave_f1=0;

//uint32_t IC_TIMES;  // �����������λ1ms
//uint8_t IC_START_FLAG;  // ����ʼ��־��1���Ѳ��񵽸ߵ�ƽ��0����û�в��񵽸ߵ�ƽ
//uint8_t IC_DONE_FLAG;  // ������ɱ�־��1�������һ�θߵ�ƽ����
//uint16_t IC_VALUE;  // ���벶��Ĳ���ֵ
uint8_t key;
char text[60];
uint16_t freq=0,freq1,freq2,test_freq;
uint8_t amp=100;
float test_amp,amp1;
uint8_t a,b,c,d,e,flag;
int temp1,temp2;
int f1,f2;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */


// *Data: �����DFT�����ԭʼ����ָ��
// num���ɼ�������
// N����Ҫ����ĵڼ������ݵ�
float DFT_Calculation(float *Data, int num, int N)
{
        unsigned int i;
        float SUM_Re = 0;        //ʵƵ��ֵ
        float SUM_Im = 0;        //��Ƶ��ֵ
        float result = 0;            // ������
        
        //FFTչ��ʽ
        for(i=0;i<num;i++)
        {
            SUM_Re = SUM_Re + Data[i]*cos(2*3.1415926*N*i/num);
            SUM_Im = SUM_Im - Data[i]*sin(2*3.1415926*N*i/num);
        }
 
        //�����ֵ
        result = sqrt(SUM_Re*SUM_Re + SUM_Im*SUM_Im);
 
        return result;
}
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
//	uint16_t adcx;
//	float temp;
//	float ad_value;
//	uint32_t time = 0;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_ADC1_Init();
  MX_TIM8_Init();
  MX_FSMC_Init();
  MX_TIM14_Init();
  /* USER CODE BEGIN 2 */
  LCD_Init();
  //������ɫ
  POINT_COLOR=BLACK;
  //����
  LCD_Clear(WHITE);
//  HAL_TIM_IC_Start_IT(&htim2,TIM_CHANNEL_1);  //����TIM2�Ĳ���ͨ��1
//  __HAL_TIM_ENABLE_IT(&htim2,TIM_IT_UPDATE);  //ʹ�ܸ����ж�
  
  HAL_TIM_Base_Start(&htim8);//����TIM3,ADC����Ƶ��20Khz
  HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADC_1_Value_DMA, FFT_LENGTH);//����ADC
  
  //HAL_Delay(2000);

  AD9833_WaveSeting(1000,0,SIN_WAVE,0);
  AD9833_AmpSet(255);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	 HAL_UART_Receive_IT(&huart1, (uint8_t *)g_rx_buffer, RXBUFFERSIZE);  //���ڽ����ж�	 
	  
	  
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  
	//���ڵ���AD9833����
    if (g_usart_rx_sta & 0x8000)
      {
		 if(g_usart_rx_buf[0]==53){
			 a = g_usart_rx_buf[1] > 58 ? g_usart_rx_buf[1] - 55 : g_usart_rx_buf[1] - 48;
			 b = g_usart_rx_buf[2] > 58 ? g_usart_rx_buf[2] - 55 : g_usart_rx_buf[2] - 48;
			 c = g_usart_rx_buf[3] > 58 ? g_usart_rx_buf[3] - 55 : g_usart_rx_buf[3] - 48;
			 freq = a*256+b*16+c;
		 }
		 if(g_usart_rx_buf[4]==53){
			 d = g_usart_rx_buf[5] > 58 ? g_usart_rx_buf[5] - 55 : g_usart_rx_buf[5] - 48;
			 e = g_usart_rx_buf[6] > 58 ? g_usart_rx_buf[6] - 55 : g_usart_rx_buf[6] - 48;
			 amp = d*16+e;
		 }
		 AD9833_WaveSeting(freq,0,SIN_WAVE,0);
		 AD9833_AmpSet(amp);
		 printf("freq=%d amp=%d\r\n",freq,amp);
         g_usart_rx_sta = 0;
		 flag=1;
     }
	 
	 //FFT����ADC����ֵ����
  	for(i=0;i<FFT_LENGTH;i++)
    {
  	  FFT_InputBuf[2*i]=ADC_1_Value_DMA[i];
  	  FFT_InputBuf[2*i+1]=0;	//�鲿ȫ��Ϊ0
    }
	
    arm_cfft_radix4_instance_f32 scfft;	//�����ṹ�����
    arm_cfft_radix4_init_f32(&scfft,FFT_LENGTH,0,1);//��ʼ��scfft�ṹ��,�趨FFT����
    arm_cfft_radix4_f32(&scfft,FFT_InputBuf);//����Ҷ����
    HAL_Delay(1000);
    arm_cmplx_mag_f32(FFT_InputBuf,FFT_OutputBuf,FFT_LENGTH); 	            //ȡģ�÷�ֵ
    HAL_Delay(1000);
	
//��������
    for(i=45;i<205;i++)
    {
    	if(FFT_OutputBuf[i]>Fundamental_wave)
    	{
			if(Fundamental_wave1 - Fundamental_wave > 100||Fundamental_wave1 - Fundamental_wave<-100)
			{
				Fundamental_wave1=Fundamental_wave;
				Fundamental_wave=FFT_OutputBuf[i];
				Fundamental_wave_f=i;
			}
    	}
    }
	
    for(n=2;n<=20;n++)
    {
    	if(n*Fundamental_wave_f>1000)break;
    	for(k=n*Fundamental_wave_f-5;k<n*Fundamental_wave_f+5;k++)
    	{
    		if(FFT_OutputBuf[k]>Harmonic_Amplitude[n-2])
    		{
    			Harmonic_Amplitude[n-2]=FFT_OutputBuf[k];
    			Harmonic_Frequency[n-2]=k;
    		}
    	}
    }  

	
	// ��ʾ����
	LCD_ShowString(30,50,200,16,16,(uint8_t *)"Date Show:");
	sprintf(text,"AD9833:freq=%d amp=%d",freq,amp);
	LCD_ShowString(30,70,200,16,16,(uint8_t *)text);
	int temp = Fundamental_wave1/2048*3300/4095;
	
	sprintf(text,"test_amp=%d.%d",(int)(Fundamental_wave1/2048*3300/4095/1000),(int)(temp1));
	LCD_ShowString(30,90,200,16,16,(uint8_t *)text);
	sprintf(text,"test_freq=%d",(int)(Fundamental_wave_f1));
	LCD_ShowString(30,110,200,16,16,(uint8_t *)text);
	  
//	//����ʾ��ADC�ɼ���ֵ
//	for(int i = 0;i<FFT_LENGTH;i++)
//	{
//		printf("A:%f\r\n",ADC_1_Value_DMA[i]*3.3/4096.0);
////		printf("ADC_1_Value_DMA[%d]:%f\r\n",i,ADC_2_Value_DMA[i]*3.3/4096.0);
//	}
	
	
	//������ֵ
		
		temp = (temp - temp/1000);
		printf("��������=%d.%d\r\n",(int)(Fundamental_wave1/2048*3300/4095/1000),(int)(temp));
	//����Ƶ��
		printf("����Ƶ��=%d\r\n",(int)(Fundamental_wave_f1));
//	amp1=(float)Fundamental_wave/2048.0*3300.0/4095.0/1000.0;
//	freq1=(int)(Fundamental_wave_f);
//	if(amp1-0.2<0){
//		amp1=amp1*10;
//	}
//	test_amp=0.3931*amp1+0.02706;
//	if(freq1!=freq2){
//		freq1=freq2;
//		//������ֵ
//		printf("��������=%.4f\r\n",test_amp/2);
//		//����Ƶ��
//		printf("����Ƶ��=%d\r\n",(int)(Fundamental_wave_f));
//	}
  Fundamental_wave1=0;
//Fundamental_wave_f=0;
//	for(int i=0;i<FFT_LENGTH*2;i++){
//		FFT_InputBuf[i] = 0.0;
//	}
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 128;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
