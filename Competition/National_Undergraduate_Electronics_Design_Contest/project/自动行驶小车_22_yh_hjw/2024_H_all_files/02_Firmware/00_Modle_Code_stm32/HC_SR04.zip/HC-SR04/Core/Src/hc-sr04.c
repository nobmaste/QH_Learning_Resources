#include "hc-sr04.h"
#include "tim.h"
#include "delay.h"

uint16_t SR04DistanceGlobal1 = 0;
uint16_t SR04DistanceGlobal2 = 0;

uint16_t SR04Distance(void)
{
  uint16_t Distance;
  int32_t outTime = 0;
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
	delay_us(15);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
  
  
  while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) != 1)
  {
    outTime++;
    if(outTime > 10000)
    {
      break;
    }
  }
   htim3.Instance->CNT = 0;
  __HAL_TIM_ENABLE(&htim3);
  
  outTime = 0;
  while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) != 0)
  {
    outTime++;
    if(outTime > 10000)
    {
      break;
    }
  }
  __HAL_TIM_DISABLE(&htim3);
  Distance = (uint16_t)(htim3.Instance->CNT*340/20.0); 
  //sprintf(str,"V1=%d\r\n",Distance);
  //while(HAL_OK != HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), 5000));
  return Distance;
}


uint16_t SR04Distance2(void)
{
  uint16_t Distance;
  int32_t outTime = 0;
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET);
	delay_us(15);
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);
  
  
  while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6) != 1)
  {
    outTime++;
    if(outTime > 100000)
    {
      break;
    }
  }
   htim3.Instance->CNT = 0;
  __HAL_TIM_ENABLE(&htim3);
  
  outTime = 0;
  while(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6) != 0)
  {
    outTime++;
    if(outTime > 100000)
    {
      break;
    }
  }
  __HAL_TIM_DISABLE(&htim3);
  Distance = (uint16_t)(htim3.Instance->CNT*340/20.0); 
  //sprintf(str,"V2=%d\r\n",Distance);
  //while(HAL_OK != HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen(str), 5000));
  return Distance;
  
}


void  UltrasonicRanging(void)
{
	uint16_t Distance[10];
	uint16_t Distance2[10];
	uint16_t max1 = 0;
	uint16_t min1 = 0;
	uint16_t max2 = 0;
	uint16_t min2 = 0;
	int i;
	SR04DistanceGlobal1 = 0;		//	������1��õľ�����0
	SR04DistanceGlobal2 = 0;		//	������2��õľ�����0
	for(i = 0;i<5;i++)
	{
		Distance[i] = SR04Distance();
    Distance2[i] = SR04Distance2();
	}
	max1 = Distance[0];
	max2 = Distance2[0];
	min1 = Distance[0];
	min2 = Distance2[0];
 	for(i = 0;i<5;i++)
 	{
 		if(max1 < Distance[i])
 		{
 			max1 = Distance[i];
 		}
		if(max2 < Distance2[i])
 		{
 			max2 = Distance2[i];
 		}
		if(min1 > Distance[i])
 		{
 			min1 = Distance[i];
 		}
		if(min2 > Distance2[i])
 		{
 			min2 = Distance2[i];
 		}
		SR04DistanceGlobal1 = SR04DistanceGlobal1 + Distance[i];
		SR04DistanceGlobal2 = SR04DistanceGlobal2 + Distance2[i];
 	}
	SR04DistanceGlobal1 = (uint16_t)((SR04DistanceGlobal1-max1-min1)/3);
	SR04DistanceGlobal2 = (uint16_t)((SR04DistanceGlobal2-max2-min2)/3);
}

