#ifndef __TEST_H__
#define __TEST_H__


#define TEST_OFF 0
#define TEST_ON 1


void test_main(void);

#endif
