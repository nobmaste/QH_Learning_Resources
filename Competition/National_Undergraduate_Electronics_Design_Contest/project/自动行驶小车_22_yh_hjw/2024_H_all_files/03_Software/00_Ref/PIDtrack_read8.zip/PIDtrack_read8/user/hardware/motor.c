#include "motor.h"


#if DC_MOTOR

// 控制电机方向的函数
void motorDir(Motor motor, Direction direction) 
{
    // 根据电机编号选择相应的电机
    switch (motor) 
    {
        case MOTOR_1:
            // 根据方向控制电机
            if (direction == FORWARD) 
            {
                //printf("Motor 1 is running forward.\n");
                // 这里可以添加控制电机正向运行的代码
                HAL_GPIO_WritePin(motor_1A_GPIO_Port, motor_1A_Pin, GPIO_PIN_RESET);
                HAL_GPIO_WritePin(motor_1B_GPIO_Port, motor_1B_Pin, GPIO_PIN_SET);
            } 
            else if(direction == BACKWARD)
            {
                //printf("Motor 1 is running backward.\n");
                // 这里可以添加控制电机反向运行的代码
                HAL_GPIO_WritePin(motor_1A_GPIO_Port, motor_1A_Pin, GPIO_PIN_SET);
                HAL_GPIO_WritePin(motor_1B_GPIO_Port, motor_1B_Pin, GPIO_PIN_RESET);
            }
            else if (direction == STOP) {
                //printf("Motor 1 is stopped.\n");
                // 这里可以添加控制电机停转的代码
                HAL_GPIO_WritePin(motor_1A_GPIO_Port, motor_1A_Pin, GPIO_PIN_RESET);
                HAL_GPIO_WritePin(motor_1B_GPIO_Port, motor_1B_Pin, GPIO_PIN_RESET);
            }
            break;
        case MOTOR_2:
            // 根据方向控制电机
            if (direction == FORWARD) {
                //printf("Motor 2 is running forward.\n");
                // 这里可以添加控制电机正向运行的代码
                HAL_GPIO_WritePin(motor_2A_GPIO_Port, motor_2A_Pin, GPIO_PIN_RESET);
                HAL_GPIO_WritePin(motor_2B_GPIO_Port, motor_2B_Pin, GPIO_PIN_SET);
            }
            else if(direction == BACKWARD)
            {
                //printf("Motor 2 is running backward.\n");
                // 这里可以添加控制电机反向运行的代码
                HAL_GPIO_WritePin(motor_2A_GPIO_Port, motor_2A_Pin, GPIO_PIN_SET);
                HAL_GPIO_WritePin(motor_2B_GPIO_Port, motor_2B_Pin, GPIO_PIN_RESET);
            }
            else if (direction == STOP) {
                //printf("Motor 2 is stopped.\n");
                // 这里可以添加控制电机停转的代码
                HAL_GPIO_WritePin(motor_2A_GPIO_Port, motor_2A_Pin, GPIO_PIN_RESET);
                HAL_GPIO_WritePin(motor_2B_GPIO_Port, motor_2B_Pin, GPIO_PIN_RESET);
            }
            break;
//        case MOTOR_3:
//            // 根据方向控制电机
//            if (direction == FORWARD) 
//            {
//                //printf("Motor 3 is running forward.\n");
//                // 这里可以添加控制电机正向运行的代码
//                HAL_GPIO_WritePin(motor_3A_GPIO_Port, motor_3A_Pin, GPIO_PIN_SET);
//                HAL_GPIO_WritePin(motor_3B_GPIO_Port, motor_3B_Pin, GPIO_PIN_RESET);
//            } 
//            else if(direction == BACKWARD)
//            {
//                //printf("Motor 3 is running backward.\n");
//                // 这里可以添加控制电机反向运行的代码
//                HAL_GPIO_WritePin(motor_3A_GPIO_Port, motor_3A_Pin, GPIO_PIN_RESET);
//                HAL_GPIO_WritePin(motor_3B_GPIO_Port, motor_3B_Pin, GPIO_PIN_SET);
//            }
//            else if (direction == STOP) {
//                //printf("Motor 3 is stopped.\n");
//                // 这里可以添加控制电机停转的代码
//                HAL_GPIO_WritePin(motor_3A_GPIO_Port, motor_3A_Pin, GPIO_PIN_RESET);
//                HAL_GPIO_WritePin(motor_3B_GPIO_Port, motor_3B_Pin, GPIO_PIN_RESET);
//            }
//            break;
//        case MOTOR_4:
//            // 根据方向控制电机
//            if (direction == FORWARD) 
//            {
//                //printf("Motor 4 is running forward.\n");
//                // 这里可以添加控制电机正向运行的代码
//                HAL_GPIO_WritePin(motor_4A_GPIO_Port, motor_4A_Pin, GPIO_PIN_SET);
//                HAL_GPIO_WritePin(motor_4B_GPIO_Port, motor_4B_Pin, GPIO_PIN_RESET);
//            } 
//            else if(direction == BACKWARD)
//            {
//                //printf("Motor 4 is running backward.\n");
//                // 这里可以添加控制电机反向运行的代码
//                HAL_GPIO_WritePin(motor_4A_GPIO_Port, motor_4A_Pin, GPIO_PIN_RESET);
//                HAL_GPIO_WritePin(motor_4B_GPIO_Port, motor_4B_Pin, GPIO_PIN_SET);
//            }
//            else if (direction == STOP) {
//                //printf("Motor 4 is stopped.\n");
//                // 这里可以添加控制电机停转的代码
//                HAL_GPIO_WritePin(motor_4A_GPIO_Port, motor_4A_Pin, GPIO_PIN_RESET);
//                HAL_GPIO_WritePin(motor_4B_GPIO_Port, motor_4B_Pin, GPIO_PIN_RESET);
//            }
//            break;
        // 添加更多电机的情况
        default:
            //printf("Invalid motor number.\n");
            break;
    }
}

//tim_pwm各通道占空比设置函数
uint32_t PWM_SetDutyCycle(TIM_HandleTypeDef *htim,uint32_t TIM_CHANNEL_X,uint32_t dutyCycle)
{
    // 修改 PWM 通道的脉冲宽度  //编辑临时参数
    TIM_OC_InitTypeDef sConfigOC = {0};
    sConfigOC.OCMode = TIM_OCMODE_PWM1;
    sConfigOC.Pulse = dutyCycle; // 设置新的脉冲宽度
    sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;//设置通道的输出极性，如果不需要改变极性，则不需要重新设置。
    sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
    //载入临时参数，并使其生效
    HAL_TIM_PWM_ConfigChannel(htim, &sConfigOC, TIM_CHANNEL_X); // TIM_CHANNEL_X表示你选择的定时器通道

    // 使新的设置生效
    HAL_TIM_PWM_Start(htim, TIM_CHANNEL_X); // 启动 PWM 输出，TIM_CHANNEL_X表示你选择的定时器
    // 返回设置的占空比百分比
    return dutyCycle;
}

#endif

//前进
void car_go_straight(void)
{
   HAL_GPIO_WritePin(motor_1A_GPIO_Port,motor_1A_Pin,GPIO_PIN_SET);
   HAL_GPIO_WritePin(motor_1B_GPIO_Port,motor_1B_Pin,GPIO_PIN_RESET);
	
   HAL_GPIO_WritePin(motor_2A_GPIO_Port,motor_2A_Pin,GPIO_PIN_SET);
   HAL_GPIO_WritePin(motor_2B_GPIO_Port,motor_2B_Pin,GPIO_PIN_RESET);
}
 
//右转
void car_go_right(void)
{
   HAL_GPIO_WritePin(motor_1A_GPIO_Port,motor_1A_Pin,GPIO_PIN_SET);
   HAL_GPIO_WritePin(motor_1B_GPIO_Port,motor_1B_Pin,GPIO_PIN_RESET);
 
   HAL_GPIO_WritePin(motor_2A_GPIO_Port,motor_2A_Pin,GPIO_PIN_RESET);
   HAL_GPIO_WritePin(motor_2B_GPIO_Port,motor_2B_Pin,GPIO_PIN_SET);
 
}
 
//左转
void car_go_left(void)
{
   HAL_GPIO_WritePin(motor_1A_GPIO_Port,motor_1A_Pin,GPIO_PIN_RESET);
   HAL_GPIO_WritePin(motor_1B_GPIO_Port,motor_1B_Pin,GPIO_PIN_SET);
 
   HAL_GPIO_WritePin(motor_2A_GPIO_Port,motor_2A_Pin,GPIO_PIN_SET);
   HAL_GPIO_WritePin(motor_2B_GPIO_Port,motor_2B_Pin,GPIO_PIN_RESET); 
 
}
 
 
//停止
void car_go_ahead(void)
{
   HAL_GPIO_WritePin(motor_1A_GPIO_Port,motor_1A_Pin,GPIO_PIN_RESET);
   HAL_GPIO_WritePin(motor_1B_GPIO_Port,motor_1B_Pin,GPIO_PIN_RESET);
 
   HAL_GPIO_WritePin(motor_2A_GPIO_Port,motor_2A_Pin,GPIO_PIN_RESET);
   HAL_GPIO_WritePin(motor_2B_GPIO_Port,motor_2B_Pin,GPIO_PIN_RESET);
 
}
 
 
//后退
void car_go_after(void)
{
   HAL_GPIO_WritePin(motor_1A_GPIO_Port,motor_1A_Pin,GPIO_PIN_RESET);
   HAL_GPIO_WritePin(motor_1B_GPIO_Port,motor_1B_Pin,GPIO_PIN_SET);
 
   HAL_GPIO_WritePin(motor_2A_GPIO_Port,motor_2A_Pin,GPIO_PIN_RESET);
   HAL_GPIO_WritePin(motor_2B_GPIO_Port,motor_2B_Pin,GPIO_PIN_SET);
 
}

