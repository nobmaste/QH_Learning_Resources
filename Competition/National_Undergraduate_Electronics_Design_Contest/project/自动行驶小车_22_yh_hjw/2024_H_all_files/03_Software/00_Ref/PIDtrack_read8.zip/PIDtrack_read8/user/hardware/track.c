#include "track.h"
#include "main.h"


//��·Ѱ��
#define Value 0       //��ȡ����ʱΪ0�͵�ƽ������Ӳ�����޸�
uint8_t get_read[4] = {0,0,0,0};//�洢��·Ѱ����������ֵ,�ں�����Ϊ1
uint8_t last_read[4] = {0,0,0,0};
int error4 = 0;


uint8_t ValidSensorNum = 0;


//��·Ѱ��
uint8_t get_read8[8] = {0,0,0,0,0,0,0,0};
uint8_t last_read8[8] = {0,0,0,0,0,0,0,0};
int error8 = 0;

void track_Read4(void)    //4·ѭ���Ķ�ȡ
{

//    ValidSensorNum = 0;     //��ȡǰ���ѭ��ģ�������ʶ    

    if(L1 == Value){get_read[0] = 1;}else{get_read[0] = 0;}
    if(L2 == Value){get_read[1] = 1;}else{get_read[1] = 0;}    
    if(R1 == Value){get_read[2] = 1;}else{get_read[2] = 0;}
    if(R2 == Value){get_read[3] = 1;}else{get_read[3] = 0;}

//    for(int8_t j=0;j<4;j++)   //��¼�ж��ٸ�ѭ��ģ���ں�����
//    {
//        ValidSensorNum = ValidSensorNum + get_read[j];
//    }
//    printf("%d\r\n",ValidSensorNum);

//    if(ValidSensorNum >= 5)    //��С��������ʻ�Ҽ�⵽ֹͣ��ʶʱ
//    {
//        Beep_On();             //��������
//        StarTimerFlag = 1;    //��ʼ��ʱ
//    }
//    else
//    {
//        Beep_off();       //��������
//    }
}

//4·ѭ��������Ȧ
float track_Error4(void)
{
        track_Read4();           //��ȡ��·ѭ�����

        if(get_read[0] == 0 && get_read[1] == 0 && get_read[2] == 0 && get_read[3] == 0 )  //ȫ��δ��⵽��������һ��״̬
        {
            //������һ��ѭ��״̬
            //memcpy(Last_Read,Get_Read,sizeof(Get_Read));              //����Ϊ��һ�εõ�״̬
        }
        else
        {
            memcpy(last_read,get_read,sizeof(get_read));              //����Ϊ��һ�εõ�״̬
        }
        
        //��ʼ�߼��ж�
        if(last_read[0] == 0 && last_read[1] == 0 && last_read[2] == 0 && last_read[3] == 1)        //������һ����⵽
        {
             error4 = 3;           //дƫ��
        }
        else if(last_read[0] == 0 && last_read[1] == 0 && last_read[2] == 1 && last_read[3] == 1)
        {
             error4 = 2;
        }
        else if(last_read[0] == 0 && last_read[1] == 0 && last_read[2] == 1 && last_read[3] == 0)
        {
             error4 = 1;
        }
        else if(last_read[0] == 0 && last_read[1] == 1 && last_read[2] == 1 && last_read[3] == 0)   //ֱ��
        {
             error4 = 0;
        }

        else if(last_read[0] == 0 && last_read[1] == 1 && last_read[2] == 0 && last_read[3] == 0)   
        {
             error4 = -1;
        }        
        else if(last_read[0] == 1 && last_read[1] == 1 && last_read[2] == 0 && last_read[3] == 0)   
        {
             error4 = -2;
        }    
        else if(last_read[0] == 1 && last_read[1] == 0 && last_read[2] == 0 && last_read[3] == 0)   
        {
             error4 = -3;
        }    

        return error4;
}

void track_Read8(void)    //8·ѭ���Ķ�ȡ
{
    ValidSensorNum = 0;   //��ȡǰ���ѭ��ģ�������ʶ    

    if(READ1 == Value){get_read8[0] = 1;}else{get_read8[0] = 0;}
    if(READ2 == Value){get_read8[1] = 1;}else{get_read8[1] = 0;}    
    if(READ3 == Value){get_read8[2] = 1;}else{get_read8[2] = 0;}
    if(READ4 == Value){get_read8[3] = 1;}else{get_read8[3] = 0;}

    if(READ5 == Value){get_read8[4] = 1;}else{get_read8[4] = 0;}    
    if(READ6 == Value){get_read8[5] = 1;}else{get_read8[5] = 0;}    
    if(READ7 == Value){get_read8[6] = 1;}else{get_read8[6] = 0;}    
    if(READ8 == Value){get_read8[7] = 1;}else{get_read8[7] = 0;}

    for(int8_t j=0;j<8;j++)   //��¼�ж��ٸ�ѭ��ģ���ں�����
    {
        ValidSensorNum = ValidSensorNum + get_read8[j];
    }
//    printf("%d\r\n",ValidSensorNum);

//    if(ValidSensorNum >= 5)    //��С��������ʻ�Ҽ�⵽ֹͣ��ʶʱ
//    {
//        Beep_On();             //��������
//        StarTimerFlag = 1;    //��ʼ��ʱ
//    }
//    else
//    {
//        Beep_off();       //��������
//    }

}

//8·ѭ��������Ȧ
float track_Error8(void)
{
    track_Read8();           //��ȡ8·ѭ�����    

    if(get_read8[0]==0&&get_read8[1]==0&&get_read8[2]==0&&get_read8[3]==0&&get_read8[4]==0&&get_read8[5]==0&&get_read8[6]==0&&get_read8[7]==0)  //ȫδ��⣬����
    {
         //������һ��ѭ��״̬
    }
    else
    {
        memcpy(last_read8,get_read8,sizeof(get_read8));              //����Ϊ��һ�εõ�״̬
    }


        //��ʼ�߼��ж�
    if(last_read8[0]==1&&last_read8[1]==0)  
    {
         error8 = -8;
    //         error8 = -25;        
    }
//    else if(last_read8[7] == 1)   //�ұ������һ����⵽
//    {
//        error8 = -7;
//    }
    else if(last_read8[0]==1&&last_read8[1]==1)  
    {
         error8 = -6;
    //         error8 = -12;        
    }

     else if(last_read8[0]==0&&last_read8[1]==1&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = -5;
//        error8 = -10;
    }    
    else if(last_read8[0]==0&&last_read8[1]==1&&last_read8[2]==1&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = -4;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==1&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = -3;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==1&&last_read8[3]==1&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = -2;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==1&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = -1;
    }


    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==1&&last_read8[4]==1&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = 0;
    }    

    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==1&&last_read8[5]==0&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = 1;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==1&&last_read8[5]==1&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = 2;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==1&&last_read8[6]==0&&last_read8[7]==0)  
    {
         error8 = 3;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==1&&last_read8[6]==1&&last_read8[7]==0)  
    {
         error8 = 4;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==1&&last_read8[7]==0)  
    {
         error8 = 5;
    }
    else if(last_read8[0]==0&&last_read8[1]==0&&last_read8[2]==0&&last_read8[3]==0&&last_read8[4]==0&&last_read8[5]==0&&last_read8[6]==1&&last_read8[7]==1)  
    {
         error8 = 6;
    }
//        if(ValidSensorNum>=5)
//        {

//        }
//        else
//        {
//            error8 = error8 + last_read8[0]*(-20) + last_read8[7]*(-20);
//        }
    return error8;
}

float track_Error_8(void)
{
    track_Read8();           //��ȡ8·ѭ�����    
    error8 = 0;
    if(get_read8[0]==0&&get_read8[1]==0&&get_read8[2]==0&&get_read8[3]==0&&get_read8[4]==0&&get_read8[5]==0&&get_read8[6]==0&&get_read8[7]==0)  //ȫδ��⣬����
    {
         //������һ��ѭ��״̬
    }
    else
    {
        memcpy(last_read8,get_read8,sizeof(get_read8));//����Ϊ��һ�εõ�״̬
    }

    //��ʼ�߼��ж�
    for(int i = 0;i < 8;i++)
    {
        if(last_read8[i] == 1)
        {
            error8 += i;
            //ValidSensorNum++;
        }
    }
    error8 = error8 / ValidSensorNum;
    error8 -= 3.5;
    return error8;
}


