#ifndef _DRV_IMU_H_
#define _DRV_IMU_H_
#include <stdint.h>
#include "math.h"
#include <stdlib.h>

typedef struct {
    double gx;	//���ٶ�
	double gy;
	double gz;
	double ax;	//���ٶ�
	double ay;
	double az;
} GyroData;

typedef struct {
	double Q_angle;
	double Q_gyro;
	double R_angle;
    double dt;
	double P[2][2];
	double K[2];
	double angle;
	double bias;
	double rate;
	double Pdot[4];
} KalmanParam;


void mpu6050_init(void);


void mpu6050_read(int16_t *gyro,int16_t *accel,float *temperature);
double CalcYawAngle(GyroData * gyro , KalmanParam * param);
void KalmanUpdate(KalmanParam* param, double rate, double angle);
void KalmanInit(KalmanParam* param, double Q_angle, double Q_gyro, double R_angle, double dt);
void calibrateSensors();
#endif







