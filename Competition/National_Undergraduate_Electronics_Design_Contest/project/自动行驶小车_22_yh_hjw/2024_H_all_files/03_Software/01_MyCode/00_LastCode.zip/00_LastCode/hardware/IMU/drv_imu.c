#include "ti_msp_dl_config.h"
#include "drv_i2c.h"
#include "drv_imu.h"

#define SMPLRT_DIV 0x19
#define MPU_CONFIG 0x1A
#define GYRO_CONFIG 0x1B
#define ACCEL_CONFIG 0x1C
#define ACCEL_XOUT_H 0x3B
#define ACCEL_XOUT_L 0x3C
#define ACCEL_YOUT_H 0x3D
#define ACCEL_YOUT_L 0x3E
#define ACCEL_ZOUT_H 0x3F
#define ACCEL_ZOUT_L 0x40
#define TEMP_OUT_H 0x41
#define TEMP_OUT_L 0x42
#define GYRO_XOUT_H 0x43
#define GYRO_XOUT_L 0x44
#define GYRO_YOUT_H 0x45
#define GYRO_YOUT_L 0x46
#define GYRO_ZOUT_H 0x47
#define GYRO_ZOUT_L 0x48
#define PWR_MGMT_1 0x6B
#define WHO_AM_I 0x75
#define USER_CTRL 0x6A
#define INT_PIN_CFG 0x37

#define PI 3.14159265

void I2C_WriteReg(uint8_t DevAddr,uint8_t reg_addr, uint8_t *reg_data, uint8_t count);
void I2C_ReadReg(uint8_t DevAddr,uint8_t reg_addr, uint8_t *reg_data, uint8_t count);

extern GyroData Gyro;

void Single_WriteI2C(unsigned char SlaveAddress,unsigned char REG_Address,unsigned char REG_data)
{
    I2C_WriteReg(SlaveAddress,REG_Address,&REG_data,1);
}

unsigned char Single_ReadI2C(unsigned char SlaveAddress,unsigned char REG_Address)
{
    uint8_t data;
    I2C_ReadReg(SlaveAddress,REG_Address,&data,1);
    return data;
}

#define imu_adress 0x68

uint8_t read_imu[5];
void mpu6050_init(void)
{
    Single_WriteI2C(imu_adress,PWR_MGMT_1 , 0x00);//�ر������ж�,�������
    Single_WriteI2C(imu_adress,SMPLRT_DIV , 0x00); // sample rate. Fsample= 1Khz/(<this value>+1) = 1000Hz
    Single_WriteI2C(imu_adress,MPU_CONFIG , 0x02); //�ڲ���ͨ�˲�Ƶ�ʣ����ٶȼ�94hz,������98hz
    Single_WriteI2C(imu_adress,GYRO_CONFIG , 0x08);//500deg/s
    Single_WriteI2C(imu_adress,ACCEL_CONFIG, 0x10);// Accel scale 8g (4096 LSB/g)
    
    read_imu[0]=Single_ReadI2C(imu_adress,PWR_MGMT_1);
    read_imu[1]=Single_ReadI2C(imu_adress,SMPLRT_DIV);
    read_imu[2]=Single_ReadI2C(imu_adress,MPU_CONFIG);
    read_imu[3]=Single_ReadI2C(imu_adress,GYRO_CONFIG);
    read_imu[4]=Single_ReadI2C(imu_adress,ACCEL_CONFIG);
}

//������ȡ���ٶȺͽǼ��ٶ�
void mpu6050_read(int16_t *gyro,int16_t *accel,float *temperature)
{
    uint8_t buf[14];
    int16_t temp;
    I2C_ReadReg(imu_adress,ACCEL_XOUT_H,buf,14);
    accel[0]=(int16_t)((buf[0]<<8)|buf[1]);
    accel[1]=(int16_t)((buf[2]<<8)|buf[3]);
    accel[2]=(int16_t)((buf[4]<<8)|buf[5]);    
    temp        =(int16_t)((buf[6]<<8)|buf[7]);
    gyro[0]    =(int16_t)((buf[8]<<8)|buf[9]);
    gyro[1]    =(int16_t)((buf[10]<<8)|buf[11]);
    gyro[2]    =(int16_t)((buf[12]<<8)|buf[13]);
    
    Gyro.ax = accel[0];
    Gyro.ay = accel[1];
    Gyro.az = accel[2];
    
    Gyro.gx = gyro[0];
    Gyro.gy = gyro[1];
    Gyro.gz = gyro[2];
    
    *temperature=36.53f+(float)(temp/340.0f);    
}

//���¿������˲�����
void KalmanUpdate(KalmanParam* param, double rate, double angle)
{
    // Ԥ��״̬
    param->angle +=(rate -param->bias)* param->dt;
    param->Pdot[0]= param->Q_angle - param->P[0][1]- param->P[1][0];
    param->Pdot[1]=-param->P[1][1];
    param->Pdot[2]=-param->P[1][1];
    param->Pdot[3]= param->Q_gyro;
    param->P[0][0]+= param->Pdot[0]* param->dt;
    param->P[0][1]+= param->Pdot[1]* param->dt;
    param->P[1][0]+= param->Pdot[2]* param->dt;
    param->P[1][1]+= param->Pdot[3]* param->dt;
    
    // ���¿���������
    double S= param->P[0][0]+ param->R_angle;
    param->K[0]=param->P[0][0]/S;
    param->K[1]=param->P[1][0]/S;
    
    //����״̬����ֵ��״̬Э�������
    double angle_err= angle - param->angle;
    param->angle += param -> K[0] * angle_err;
    param->bias += param -> K[1] * angle_err;
    param->P[0][0] -= param->K[0] * param->P[0][0];
    param->P[0][1] -= param->K[0] * param->P[0][1];
    param->P[1][0]-= param->K[1]* param->P[0][0];
    param->P[1][1]-= param->K[1] *param->P[0][1];
}

//��ʼ���������˲�����
void KalmanInit(KalmanParam* param, double Q_angle, double Q_gyro, double R_angle, double dt)
{
    param->Q_angle =Q_angle;
    param->Q_gyro =Q_gyro;
    param->R_angle =R_angle;
    param->dt = dt;
    param->P[0][0]=0;
    param->P[0][1]= 0;
    param->P[1][0]=0;
    param->P[1][1]= 0;
    param->angle =0;
    param->bias =0;
}

//����Ƕ�
double CalcYawAngle(GyroData * gyro , KalmanParam * param)
{
    //������ٶ�����ϵ�µ�Z��Ƕ�
    double roll=atan2(gyro->ay , gyro->az) * 180 / PI;
    double pitch = atan(-gyro->ax/ sqrt(gyro->ay * gyro->ay + gyro->az * gyro->az))* 180 / PI;
    
    //������ٶȹ۲�ֵ
    double gyro_z = gyro->gz - param->bias;
    
    //ʹ�ÿ������˲�����ƫ����
    KalmanUpdate(param , gyro_z , roll);
    
    //���ؽǶ�ֵ
    return param->angle;
}

void calibrateSensors()
{
    int16_t temp_accel[3], temp_gyro[3];
    float temp_temperature;
    int num_samples = 1000;
    int32_t sum_accel[3] = {0, 0, 0}, sum_gyro[3] = {0, 0, 0};

    for (int i = 0; i < num_samples; i++)
    {
        mpu6050_read(temp_gyro, temp_accel, &temp_temperature);
        sum_accel[0] += temp_accel[0];
        sum_accel[1] += temp_accel[1];
        sum_accel[2] += temp_accel[2];
        sum_gyro[0] += temp_gyro[0];
        sum_gyro[1] += temp_gyro[1];
        sum_gyro[2] += temp_gyro[2];
    }

    Gyro.ax = sum_accel[0] / num_samples;
    Gyro.ay = sum_accel[1] / num_samples;
    Gyro.az = sum_accel[2] / num_samples;
    Gyro.gx = sum_gyro[0] / num_samples;
    Gyro.gy = sum_gyro[1] / num_samples;
    Gyro.gz = sum_gyro[2] / num_samples;
}
