#ifndef __DAC_H_
#define __DAC_H_

#include "A_include.h"

void DAC_Init(void);
void DAC_start(uint32_t DAC_value);




#endif



