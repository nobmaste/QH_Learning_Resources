#ifndef __TRACK_H_
#define __TRACK_H_

#include "A_include.h"

/*�Ҷ�ģ��*/
//��·Ѱ�����м�һ·Ѱ����
#define READ1   DL_GPIO_readPins(read_sensor_r0_PORT ,read_sensor_r0_PIN)//��ȡ�Ҷ�ģ�����ӵ�GPIO��ƽ
#define READ2   DL_GPIO_readPins(read_sensor_r1_PORT ,read_sensor_r1_PIN)
#define READ3   DL_GPIO_readPins(read_sensor_r2_PORT ,read_sensor_r2_PIN)
#define READ4   DL_GPIO_readPins(read_sensor_r3_PORT ,read_sensor_r3_PIN)
#define READ5   DL_GPIO_readPins(read_sensor_r4_PORT ,read_sensor_r4_PIN)
#define READ6   DL_GPIO_readPins(read_sensor_r5_PORT ,read_sensor_r5_PIN)
#define READ7   DL_GPIO_readPins(read_sensor_r6_PORT ,read_sensor_r6_PIN)
#define READ8   DL_GPIO_readPins(read_sensor_r7_PORT ,read_sensor_r7_PIN)

void track_Read4(void);
float track_Error4(void);

void track_Read8(void);
float track_Error8(void);

float track_Error_8(void);

#endif
