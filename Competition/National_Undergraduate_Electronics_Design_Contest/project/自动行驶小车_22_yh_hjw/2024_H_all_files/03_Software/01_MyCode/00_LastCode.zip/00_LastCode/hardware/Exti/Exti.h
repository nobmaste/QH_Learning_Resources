#ifndef _Exti_H_
#define _Exti_H_


#include "A_include.h"


void Exti_Init(void);


#endif

