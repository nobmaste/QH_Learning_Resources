#ifndef __MYSPI_H_
#define __MYSPI_H_

#include "A_include.h"

uint8_t SPI_WriteByte(uint8_t Byte);
void SPI_Send_cmd(uint8_t cmd);

#endif



