#ifndef __Motor_H
#define __Motor_H

#include "A_include.h"

void Motor_Init(void);
void Motor0_Ctrl(int duty0,int duty1);
void Motor1_Ctrl(int duty0,int duty1);

void  set_duty(float duty,uint8_t channe1);
void set_motor0_freq(uint32_t freq,uint8_t channe1);
void set_motor1_freq(uint32_t freq,uint8_t channe1);


#endif























