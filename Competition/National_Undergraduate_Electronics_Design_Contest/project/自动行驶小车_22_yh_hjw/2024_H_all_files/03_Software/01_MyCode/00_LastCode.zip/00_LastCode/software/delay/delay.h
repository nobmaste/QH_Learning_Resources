#ifndef _DELAY_H_
#define _DELAY_H_


#include "A_include.h"


void delay_ms(unsigned int sx);
void delay_us(unsigned int sx);


#endif

