#include "timer.h"

int cnt	= 0;

void Timer_Init(void)
{
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
		DL_TimerG_startCounter(TIMER_0_INST);
}

/*100ms��ʱ��*/
void TIMER_0_INST_IRQHandler(void)
{
    if(DL_Timer_getPendingInterrupt(TIMER_0_INST) == DL_TIMER_IIDX_ZERO)
    {		
				cnt++;
				LED_togglePins;
				//Key_Scan();
				if(cnt >= 5)	//cnt*100ms
				{	
						DL_GPIO_setPins(GPIOB , DL_GPIO_PIN_9);//���⴫�����ر�
						//ֹͣ����
						NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
						DL_TimerG_stopCounter(TIMER_0_INST);
						cnt = 0;//����
					
				}
    }
}









