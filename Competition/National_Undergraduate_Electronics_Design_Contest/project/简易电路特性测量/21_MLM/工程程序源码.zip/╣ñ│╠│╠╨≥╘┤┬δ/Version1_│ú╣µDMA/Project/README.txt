AD9833
		GPIOB_Pin_15 		---> FSYNC
		GPIOB_Pin_14 		---> SCK
		GPIOB_Pin_13 		---> DAT
		GPIOB_Pin_12		---> CS
		
		
USART		
PA.9    --->TX
PA.10   --->RX


ADC
PA.0
PA.1
PA.2

switch_control
PA.4	--->switch_A
PA.5	--->switch_B
PA.6	--->switch_C
PA.7	--->switch_D