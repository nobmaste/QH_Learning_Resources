#ifndef __TASK_H__
#define __TASK_H__

#define Ri 7500
#define Ro 1500
#define Vi_AcOrigin 33
void task_Basic_Print(void);
void task_data_F(void);
void task_analyze(void);
void sampling(void);
void sampling_F(void);
#endif







