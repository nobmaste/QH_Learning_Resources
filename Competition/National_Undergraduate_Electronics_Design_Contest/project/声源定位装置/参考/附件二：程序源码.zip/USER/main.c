#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "math.h"
#include "led.h"
#include "key.h"
#include "exti.h"
#include "timer.h"
#include "AD9959.h"

u8 key;
extern TIM_HandleTypeDef TIM3_Handler;      //��ʱ����� 
extern u32 tim[3];
u32 table[36][3]=
{
	{10,58,0},{35,64,0},{68,72,0},{99,81,0},{135,93,0},{171,106,0},
	{0,55,18},{10,41,0},{40,48,0},{72,54,0},{105,59,0},{133,66,0},
	{0,63,48},{0,35,18},{9,17,0},{43,20,0},{70,21,0},{98,22,0},		
	{0,70,80},{0,41,51},{0,10,22},{23,0,13},{55,0,16},{86,0,16},
	{0,82,133},{0,47,83},{0,13,54},{25,0,46},{64,0,53},{95,0,58},
	{0,95,149},{0,54,114},{0,13,80},{26,0,76},{69,0,86},{106,0,97}
//{},{},{},{},{},{},		
};
char *label[]=
{
	"AB,0102","CD,0102","EF,0102","GH,0102","IJ,0102","KL,0102",
	"AB,0304","CD,0304","EF,0304","GH,0304","IJ,0304","KL,0304",
	"AB,0506","CD,0506","EF,0506","GH,0506","IJ,0506","KL,0506",
	"AB,0708","CD,0708","EF,0708","GH,0708","IJ,0708","KL,0708",
	"AB,0910","CD,0910","EF,0910","GH,0910","IJ,0910","KL,0910",
	"AB,1112","CD,1112","EF,1112","GH,1112","IJ,1112","KL,1112"
	};
u32 deta[36];
char *result;
int resultlabel;
int i;
int min(u32 arry[36]);
int a=24;
int x;
int y;
char* tap[]={"page0.t0.bco=BLACK","page0.t1.bco=BLACK","page0.t2.bco=BLACK","page0.t3.bco=BLACK","page0.t4.bco=BLACK","page0.t5.bco=BLACK",
              "page0.t6.bco=BLACK","page0.t7.bco=BLACK","page0.t8.bco=BLACK","page0.t9.bco=BLACK","page0.t10.bco=BLACK","page0.t11.bco=BLACK",
             "page0.t12.bco=BLACK","page0.t13.bco=BLACK","page0.t14.bco=BLACK","page0.t15.bco=BLACK","page0.t16.bco=BLACK","page0.t17.bco=BLACK",
              "page0.t18.bco=BLACK","page0.t19.bco=BLACK","page0.t20.bco=BLACK","page0.t21.bco=BLACK","page0.t22.bco=BLACK","page0.t23.bco=BLACK",
             "page0.t24.bco=BLACK","page0.t25.bco=BLACK","page0.t26.bco=BLACK","page0.t27.bco=BLACK","page0.t28.bco=BLACK","page0.t29.bco=BLACK",
              "page0.t30.bco=BLACK","page0.t31.bco=BLACK","page0.t32.bco=BLACK","page0.t33.bco=BLACK","page0.t34.bco=BLACK","page0.t35.bco=BLACK"};
char* tap1[]={"page0.t0.bco=WHITE","page0.t1.bco=WHITE","page0.t2.bco=WHITE","page0.t3.bco=WHITE","page0.t4.bco=WHITE","page0.t5.bco=WHITE",
              "page0.t6.bco=WHITE","page0.t7.bco=WHITE","page0.t8.bco=WHITE","page0.t9.bco=WHITE","page0.t10.bco=WHITE","page0.t11.bco=WHITE",
             "page0.t12.bco=WHITE","page0.t13.bco=WHITE","page0.t14.bco=WHITE","page0.t15.bco=WHITE","page0.t16.bco=WHITE","page0.t17.bco=WHITE",
              "page0.t18.bco=WHITE","page0.t19.bco=WHITE","page0.t20.bco=WHITE","page0.t21.bco=WHITE","page0.t22.bco=WHITE","page0.t23.bco=WHITE",
             "page0.t24.bco=WHITE","page0.t25.bco=WHITE","page0.t26.bco=WHITE","page0.t27.bco=WHITE","page0.t28.bco=WHITE","page0.t29.bco=WHITE",
              "page0.t30.bco=WHITE","page0.t31.bco=WHITE","page0.t32.bco=WHITE","page0.t33.bco=WHITE","page0.t34.bco=WHITE","page0.t35.bco=WHITE"};
char* xtap[]={"page0.t64.txt=\"AB\"","page0.t64.txt=\"CD\"","page0.t64.txt=\"EF\"","page0.t64.txt=\"GH\"","page0.t64.txt=\"IJ\"","page0.t64.txt=\"KL\""};
char* ytap[]={"page0.t65.txt=\"0102\"","page0.t65.txt=\"0304\"","page0.t65.txt=\"0506\"","page0.t65.txt=\"0708\"","page0.t65.txt=\"0910\"","page0.t65.txt=\"1112\""};

int main(void)
{
  HAL_Init();                    	//��ʼ��HAL��    
  Stm32_Clock_Init(336,8,2,7);  	//����ʱ��,168Mhz
	delay_init(168);               	//��ʼ����ʱ����
	uart_init(9600);              //��ʼ��USART
	LED_Init();						//��ʼ��LED	
  KEY_Init();                     //��ʼ������
	delay_ms(500);//��ʱһ������ȴ��ϵ��ȶ�,ȷ��AD9959�ȿ��ư����ϵ硣
	AD9959_Init();								//��ʼ������AD9959��Ҫ�õ���IO��,���Ĵ���
	TIM3_Init(50000-1,84-1);   //��ʱ��3��ʼ������ʱ��ʱ��Ϊ84M����Ƶϵ��Ϊ84-1��
                                    //���Զ�ʱ��3��Ƶ��Ϊ84M/84=1000K���Զ���װ��Ϊ50000-1����ô��ʱ�����ھ���50ms
  while(1)
  {
		key=KEY_Scan(0);
		if(key==KEY0_PRES&&LED0==1)
		{
			LED0 =0;
			while(1)
			{
				for(int i=15;i<21;i++)
				{
					AD9959_Set_Fre(CH0, 1000*i);	//����ͨ��0Ƶ��Hz
					AD9959_Set_Amp(CH0, 1023); 		//����ͨ��0���ȿ���ֵ1023����Χ0~1023
					AD9959_Set_Phase(CH0, 0);			//����ͨ��0��λ����ֵ0(0��)����Χ0~16383
					IO_Update();	//AD9959��������,���ô˺���������������Ч������
					delay_ms(5000/6);
				}
			}
		}
		if(key==WKUP_PRES&&LED1==1)
		{
			while(1)
			{
				delay_ms(300);
				LED1 =0;
				EXTI_Init();			//�ⲿ�жϳ�ʼ��
				while(tim[0]==0&&tim[1]==0&&tim[2]==0);
				delay_ms(50);
////		Ӧ�ò��ұ���
				if((tim[0]<500&&tim[1]<500&&tim[2]<500)&&(tim[0]>3||tim[1]>3||tim[2]>3))
				{
//					u32 deta[36]={0};
//					char *result;
//					int resultlabel;
					for(i = 0; i < 36; i++)
					{
						deta[i]=0;
					}
					for (i = 0; i < 36; i++) 
					{
						for (int j = 0; j < 3; j++) 
						{	
							deta[i] = deta[i]+(table[i][j]-tim[j])*(table[i][j]-tim[j]);
						}
					}
					resultlabel=min(deta);
					a=resultlabel;
										x=a%6;
				 y=a/6;   
						for(i=0;i<36;i++)
				 {
					printf("%s",tap1[i]);
					 printf("\xff\xff\xff");
				 }   
				 printf("%s",tap[a]);
				 printf("\xff\xff\xff");
				 printf("%s",xtap[x]);
				 printf("\xff\xff\xff");
				 printf("%s",ytap[y]);
				 printf("\xff\xff\xff");
//				result = label[resultlabel];
//				printf("(%s)\r\n",result);
				}
//		�������ұ���	
//				printf("%d\r\n",tim[0]);
//				printf("%d\r\n",tim[1]);
//				printf("%d\r\n",tim[2]);
				tim[0]=0;
				 tim[1]=0;
				 tim[2]=0;
				a=0;
				HAL_TIM_Base_Stop_IT(&TIM3_Handler);
				__HAL_TIM_SET_COUNTER(&TIM3_Handler,0);
				__HAL_RTC_TAMPER_TIMESTAMP_EXTI_CLEAR_FLAG();
			}
		}
		delay_ms(100);
	}
}

int min(u32 arry[36])
{
	int n=0;
	for( i=1;i<36;i++)
	{
		if (arry[i]<arry[n]){
			n=i;
		}
		else
			n=n;
		}
	return n;
}
